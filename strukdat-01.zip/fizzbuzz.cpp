/*Nama : Anugerah Prima Bagaskara
NPM : 140810180006
Tahun : 2019
Deskripsi : Fizzbuzz apabila angka dapat dibagi 3 dan 5
*/
#include <iostream>
using namespace std;

void fizzbuzz(int&n){
	cout<<"Masukkan jumlah angka : ";cin>>n;
	for(int a=n;a>0;a--){
	if(a%3==0 || a%5==0){
		cout<<"Fizzbuzz";
		cout<<endl;
	}
	else{
		cout<<a;
		cout<<endl;
	}
}
}

int main(){
	int n;
	fizzbuzz(n);
	}
