/*Nama : Anugerah Prima Bagaskara
NPM : 140810180006
Tahun : 2019
Deskripsi : Mengubah celcius ke fahrenheit
*/
#include <iostream>
using namespace std;

float cel2Fah(float temp){
	return temp *9/5 +32;
}

int main(){
	int celcius = 10;
	float fahrenheit = cel2Fah(celcius);
	cout<<"temp is " << fahrenheit;
}
